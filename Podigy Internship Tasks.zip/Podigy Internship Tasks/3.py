import re

def password_strength(password):
    length = len(password)
    uppercase = bool(re.search(r"[A-Z]", password))
    lowercase = bool(re.search(r"[a-z]", password))
    numbers = bool(re.search(r"\d", password))
    special_chars = bool(re.search(r"[!@#$%^&*()-_=+{};:,<.>]", password))

    score = 0

    if length >= 8:
        score += 1
    if uppercase:
        score += 1
    if lowercase:
        score += 1
    if numbers:
        score += 1
    if special_chars:
        score += 1

    if score <= 2:
        return "Weak"
    elif score <= 3:
        return "Moderate"
    elif score <= 4:
        return "Strong"
    else:
        return "Very strong"

def main():
    password = input("Enter your password: ")
    strength = password_strength(password)
    print("Password strength:", strength)

if __name__ == "__main__":
    main()
