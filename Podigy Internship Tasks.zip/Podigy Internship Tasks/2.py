from PIL import Image

def encrypt_image(image_path):
    img = Image.open(image_path)
    width, height = img.size
    encrypted_pixels = []
    for y in range(height):
        for x in range(width):
            pixel = img.getpixel((x, y))
            encrypted_pixel = (pixel[2], pixel[0], pixel[1])  # Swapping RGB values
            encrypted_pixels.append(encrypted_pixel)
    encrypted_img = Image.new(img.mode, (width, height))
    encrypted_img.putdata(encrypted_pixels)
    encrypted_img.save("encrypted_image.png")
    print("Image encrypted successfully!")

def decrypt_image(encrypted_image_path):
    encrypted_img = Image.open(encrypted_image_path)
    width, height = encrypted_img.size
    decrypted_pixels = []
    for y in range(height):
        for x in range(width):
            encrypted_pixel = encrypted_img.getpixel((x, y))
            decrypted_pixel = (encrypted_pixel[1], encrypted_pixel[2], encrypted_pixel[0])  # Swapping RGB values back
            decrypted_pixels.append(decrypted_pixel)
    decrypted_img = Image.new(encrypted_img.mode, (width, height))
    decrypted_img.putdata(decrypted_pixels)
    decrypted_img.save("decrypted_image.png")
    print("Image decrypted successfully!")

def main():
    choice = input("Enter 'E' to encrypt or 'D' to decrypt: ").upper()
    if choice == 'E':
        image_path = input("Enter the path of the image to encrypt: ")
        encrypt_image(image_path)
    elif choice == 'D':
        encrypted_image_path = input("Enter the path of the encrypted image to decrypt: ")
        decrypt_image(encrypted_image_path)
    else:
        print("Invalid choice. Please enter 'E' or 'D'.")

if __name__ == "__main__":
    main()
